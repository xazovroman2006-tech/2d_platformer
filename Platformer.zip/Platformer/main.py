import pygame
from sys import exit
from settings import GAME_WIDTH, GAME_HEIGHT
from assets import load_assets
from player import Player

pygame.init()
window = pygame.display.set_mode((GAME_WIDTH, GAME_HEIGHT), pygame.FULLSCREEN)
clock = pygame.time.Clock()

assets = load_assets()

pygame.display.set_caption("7 порокв Захарда")
pygame.display.set_icon(assets["idle_right"])

player = Player(assets)

def draw():
    window.blit(assets["background"], (0, 0))
    window.blit(player.image, player)

    if player.show_hit_effect:
        hit = assets[f"hit_{player.direction}"]  # автоматически right или left
        if player.direction == "right":
            hit_x = player.x + player.width
        else:
            hit_x = player.x - hit.get_width()
        hit_y = player.y + (player.height - hit.get_height()) // 2
        window.blit(hit, (hit_x, hit_y))

while True:
    events = pygame.event.get()
    for event in events:
         if event.type == pygame.QUIT:
            pygame.quit()
            exit()

    keys = pygame.key.get_pressed()
    player.update(keys, events, GAME_WIDTH, GAME_HEIGHT)

    draw()
    pygame.display.update()
    clock.tick(60)