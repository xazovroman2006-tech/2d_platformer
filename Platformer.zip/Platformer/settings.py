GAME_WIDTH = 1724
GAME_HEIGHT = 1000

PLAYER_X = GAME_WIDTH / 2
PLAYER_Y = GAME_HEIGHT / 2
PLAYER_WIDTH = 52 * 2
PLAYER_HEIGHT = 80 * 2

HIT_WIDTH = 39
HIT_HEIGHT = 20

PLAYER_DISTANCE = 5

ANIMATION_SPEED = 4

JUMP_ANIMATION_SPEED = 8

# Прыжок
JUMP_FORCE = -20      # Начальная скорость прыжка (отрицательная = вверх)
GRAVITY = 0.8      # Ускорение падения
GROUND_Y = GAME_HEIGHT - PLAYER_HEIGHT - 10  # Уровень земли
