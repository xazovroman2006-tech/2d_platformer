import pygame
from settings import (
    PLAYER_X, PLAYER_Y, PLAYER_WIDTH, PLAYER_HEIGHT,
    PLAYER_DISTANCE, ANIMATION_SPEED, JUMP_ANIMATION_SPEED,
    JUMP_FORCE, GRAVITY, GROUND_Y, JUMP_BUFFER_FRAMES
)

class Player(pygame.Rect):
    def __init__(self, assets):
        pygame.Rect.__init__(self, int(PLAYER_X), int(PLAYER_Y), int(PLAYER_WIDTH), int(PLAYER_HEIGHT))
        self.assets = assets
        self.image = assets["idle_right"]
        self.direction = "right"
        self.frame_index = 0
        self.animation_timer = 0
        self.attacking = False
        self.show_hit_effect = False

        self.velocity_y = 0.0
        self.float_y = float(PLAYER_Y)  # храним float отдельно
        self.on_ground = False
        self.jump_phase = "none"
        self.jump_buffer = 0        # счётчик буфера
        JUMP_BUFFER_FRAMES = 10     # сколько кадров запоминать нажатие

    def handle_jump(self, keys):
        jumped = (
            keys[pygame.K_SPACE] or
            keys[pygame.K_UP] or
            keys[pygame.K_w]
        )
        
        # Если нажали прыжок — заряжаем буфер
        if jumped:
            self.jump_buffer = JUMP_BUFFER_FRAMES
        elif self.jump_buffer > 0:
            self.jump_buffer -= 1  # буфер тикает каждый кадр

        # Прыгаем если буфер активен и стоим на земле
        if self.jump_buffer > 0 and self.on_ground:
            self.velocity_y = JUMP_FORCE
            self.on_ground = False
            self.jump_phase = "start"
            self.frame_index = 0
            self.animation_timer = 0
            self.jump_buffer = 0  # сбрасываем буфер после прыжка
            self.animation_timer = 0

        if not jumped and self.velocity_y < 0:
            self.velocity_y *= 0.85


    def apply_gravity(self):
        self.velocity_y += GRAVITY
        self.float_y += self.velocity_y  # считаем в float
        self.y = int(self.float_y)       # в Rect пишем int

        if self.y >= GROUND_Y:
            self.float_y = float(GROUND_Y)
            self.y = GROUND_Y
            self.velocity_y = 0.0
            if not self.on_ground:
                self.jump_phase = "land"
                self.frame_index = 0
                self.animation_timer = 0
            self.on_ground = True
        else:
            if self.jump_phase == "start":
                self.jump_phase = "air"

    def handle_input(self, keys, game_width, game_height):
        if self.attacking:
            return False

        moving = False

        '''if (keys[pygame.K_DOWN] or keys[pygame.K_s]) and self.y + self.height + PLAYER_DISTANCE <= game_height:
            self.float_y += PLAYER_DISTANCE
            self.y = int(self.float_y)
            moving = True


        '''
        if (keys[pygame.K_LEFT] or keys[pygame.K_a]) and self.x - PLAYER_DISTANCE >= 0:
            self.x -= PLAYER_DISTANCE
            self.direction = "left"
            moving = True
        if (keys[pygame.K_RIGHT] or keys[pygame.K_d]) and self.x + self.width + PLAYER_DISTANCE <= game_width:
            self.x += PLAYER_DISTANCE
            self.direction = "right"
            moving = True

        return moving

    def handle_attack(self, events):
        for event in events:
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                if not self.attacking:
                    self.attacking = True
                    self.frame_index = 0
                    self.animation_timer = 0

    def update_animation(self, moving):
        if self.attacking:
            attack_frames = self.assets[f"attack_{self.direction}"]
            self.animation_timer += 1
            if self.animation_timer >= ANIMATION_SPEED:
                self.animation_timer = 0
                self.frame_index += 1
                self.show_hit_effect = (self.frame_index == 4)
                if self.frame_index >= len(attack_frames):
                    self.attacking = False
                    self.frame_index = 0
                    return
            self.image = attack_frames[self.frame_index]

        elif not self.on_ground or self.jump_phase in ("start", "land"):
            jump_frames = self.assets[f"jump_{self.direction}"]
            phase_frames = {
                "start": [0, 1],
                "air":   [2],
                "land":  [3, 4],
            }
            frames = phase_frames.get(self.jump_phase, [2])

            self.animation_timer += 1
            if self.animation_timer >= JUMP_ANIMATION_SPEED:
                self.animation_timer = 0
                local_index = frames.index(self.frame_index) if self.frame_index in frames else 0
                next_index = local_index + 1
                if next_index < len(frames):
                    self.frame_index = frames[next_index]
                else:
                    self.frame_index = frames[-1]
                    if self.jump_phase == "land":
                        self.jump_phase = "none"

            if self.frame_index < len(jump_frames):
                self.image = jump_frames[self.frame_index]

        elif moving:
            run_frames = self.assets[f"run_{self.direction}"]
            if self.frame_index >= len(run_frames):
                self.frame_index = 0
            self.animation_timer += 1
            if self.animation_timer >= ANIMATION_SPEED:
                self.animation_timer = 0
                self.frame_index = (self.frame_index + 1) % len(run_frames)
            self.image = run_frames[self.frame_index]

        else:
            self.frame_index = 0
            self.animation_timer = 0
            self.image = self.assets[f"idle_{self.direction}"]

    def update(self, keys, events, game_width, game_height):
        self.handle_attack(events)
        self.handle_jump(keys)
        moving = self.handle_input(keys, game_width, game_height)
        self.apply_gravity()
        self.update_animation(moving)