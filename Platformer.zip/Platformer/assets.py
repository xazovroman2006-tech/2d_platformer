import pygame
import os
from settings import PLAYER_WIDTH, PLAYER_HEIGHT, HIT_WIDTH, HIT_HEIGHT

# Папка с картинками
BASE_DIR = os.path.dirname(__file__)
IMAGES_DIR = os.path.join(BASE_DIR, "images")

def load_assets():
    background = pygame.image.load(os.path.join(IMAGES_DIR, "background.png"))

    idle_right = pygame.image.load(os.path.join(IMAGES_DIR, "stay.png"))
    idle_right = pygame.transform.scale(idle_right, (PLAYER_WIDTH, PLAYER_HEIGHT))
    idle_left = pygame.transform.flip(idle_right, True, False)

    run_right = []
    for i in range(1, 7):
        img = pygame.image.load(os.path.join(IMAGES_DIR, f"run_right_{i}.png"))
        img = pygame.transform.scale(img, (PLAYER_WIDTH, PLAYER_HEIGHT))
        run_right.append(img)

    run_left = [pygame.transform.flip(img, True, False) for img in run_right]

    jump_right = []
    jump_left = []
    for i in range(1, 6):
        img = pygame.image.load(os.path.join(IMAGES_DIR, f"jump_{i}.png"))
        img = pygame.transform.scale(img, (PLAYER_WIDTH, PLAYER_HEIGHT))
        jump_right.append(img)
        jump_left.append(pygame.transform.flip(img, True, False))

    attack_right = []
    for i in range(1, 3):  # 6 кадров
        img = pygame.image.load(os.path.join(IMAGES_DIR, f"attack_right_{i}.png"))
        img = pygame.transform.scale(img, (PLAYER_WIDTH, PLAYER_HEIGHT))
        attack_right.append(img)

    attack_left = [pygame.transform.flip(img, True, False) for img in attack_right]

    hit_right = pygame.image.load(os.path.join(IMAGES_DIR, "hit_1.png"))
    hit_right = pygame.transform.scale(hit_right, (HIT_WIDTH, HIT_HEIGHT))
    hit_left = pygame.transform.flip(hit_right, True, False)

    return {
        "background": background,
        "idle_right": idle_right,
        "idle_left": idle_left,
        "run_right": run_right,
        "run_left": run_left,
        "attack_right": attack_right,
        "attack_left": attack_left,
        "hit_right": hit_right,
        "hit_left": hit_left,
        "jump_right": jump_right,
        "jump_left": jump_left,
    }